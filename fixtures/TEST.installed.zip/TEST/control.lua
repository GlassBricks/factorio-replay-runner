require('__base__/script/freeplay/control.lua')


-- Begin replay script
local ____event_handler = require("event_handler")
local add_lib = ____event_handler.add_lib
local util = require("util")
_G.util = util
local function logEvent(____type, ...)
    local args = {...}
    print(
        "REPLAY_SCRIPT_EVENT:",
        game.ticks_played,
        ____type,
        table.concat(args, " ")
    )
end
ReplayLog = {
    err = function(self, ...)
        logEvent("Error", ...)
    end,
    warn = function(self, ...)
        logEvent("Warn", ...)
    end,
    info = function(self, ...)
        logEvent("Info", ...)
    end
}
addReplayLib = function(lib)
    if not lib.events then
        lib.events = {}
    end
    for name, fn in pairs(lib) do
        if defines.events[name] ~= nil then
            lib.events[defines.events[name]] = fn
        end
    end
    add_lib(lib)
end
local afterReplayFns = {}
afterReplay = function(fn)
    afterReplayFns[#afterReplayFns + 1] = fn
end
addReplayLib({
    on_init = function()
        storage._REPLAY_SCRIPT_DATA = {}
    end,
    on_load = function()
        if storage._REPLAY_SCRIPT_DATA ~= nil then
            return
        end
        script.on_event(
            defines.events.on_tick,
            function()
                for ____, fn in ipairs(afterReplayFns) do
                    fn()
                end
            end
        )
    end
})
-- Script: no_bad_console_commands
-- Lua Library inline imports
local function __TS__StringTrim(self)
    local result = string.gsub(self, "^[%s ﻿]*(.-)[%s ﻿]*$", "%1")
    return result
end
-- End of Lua Library inline imports
allowedCommands = util.list_to_map({
    "admins",
    "ban",
    "banlist",
    "bans",
    "clear",
    "color",
    "demote",
    "evolution",
    "h",
    "help",
    "ignore",
    "ignores",
    "kick",
    "mute",
    "mute-programmable-speaker",
    "mutes",
    "p",
    "players",
    "promote",
    "purge",
    "r",
    "reply",
    "reset-tips",
    "s",
    "screenshot",
    "seed",
    "server-save",
    "shout",
    "time",
    "unban",
    "unignore",
    "unlock-shortcut-bar",
    "unlock-tips",
    "unmute",
    "version",
    "w",
    "whisper",
    "whitelist"
})
addReplayLib({on_console_command = function(event)
    local ____temp_2 = event.player_index ~= nil
    if ____temp_2 then
        local ____opt_0 = game.get_player(event.player_index)
        ____temp_2 = ____opt_0 and ____opt_0.name
    end
    local player = ____temp_2 or "server"
    if event.command == "editor" then
        return
    end
    if allowedCommands[event.command] ~= nil or event.command == "config" and __TS__StringTrim(event.parameters) == "set allow-debug-settings false" then
        ReplayLog:info(player, "ran:", "/" .. event.command, event.parameters)
    elseif event.command == "admin" then
        ReplayLog:warn(player, "ran:", "/" .. event.command, event.parameters)
    else
        ReplayLog:err(player, "ran disallowed command:", "/" .. event.command, event.parameters)
    end
end})
-- Script: no_blueprint_import
addReplayLib({on_player_cursor_stack_changed = function(event)
    if storage._REPLAY_SCRIPT_DATA["import-blueprint"] ~= nil then
        return
    end
    local player = game.get_player(event.player_index)
    local record = player.cursor_record
    if record and not record.valid_for_write then
        storage._REPLAY_SCRIPT_DATA["import-blueprint"] = true
        ReplayLog:err(player.name, "imported a blueprint from the blueprint library!")
    end
end})
-- Script: log_time
addReplayLib({on_nth_tick = {[60 * 15] = function()
    local seconds = math.floor(game.ticks_played / 60)
    local minutes = math.floor(seconds / 60)
    local hours = math.floor(minutes / 60)
    local shouldLog = false
    if hours < 2 then
        shouldLog = minutes % 5 == 0 and seconds == 0
    elseif hours < 4 then
        shouldLog = seconds == 0
    elseif hours < 5 then
        shouldLog = seconds % 30 == 0
    elseif hours < 6 then
        shouldLog = seconds % 15 == 0
    end
    if shouldLog then
        local h = hours
        local m = minutes % 60
        local s = seconds % 60
        ReplayLog:info(string.format("%02d:%02d:%02d", h, m, s))
    end
end}})
-- Script: no_map_editor
addReplayLib({on_player_toggled_map_editor = function(event)
    local player = game.get_player(event.player_index).name
    ReplayLog:err(player, "used map editor!")
end})
-- Script: max_players
addReplayLib({on_player_joined_game = function(event)
    local maxPlayers = 1
    if #game.players > maxPlayers then
        ReplayLog:err((("Too many players! Maximum allowed: " .. tostring(maxPlayers)) .. ", current: ") .. tostring(#game.players))
    end
end})
-- Script: no_open_other_player
addReplayLib({on_gui_opened = function(event)
    if event.gui_type == defines.gui_type.other_player then
        local player = game.get_player(event.player_index)
        local otherPlayer = event.other_player
        ReplayLog:warn(player and player.name or "unknown", "opened", otherPlayer and otherPlayer.name or "unknown", "player's GUI!")
    end
end})
-- Script: win_on_rocket_launch
addReplayLib({
    on_rocket_launched = function()
        if storage._REPLAY_SCRIPT_DATA["first-rocket"] ~= nil then
            return
        end
        storage._REPLAY_SCRIPT_DATA["first-rocket"] = true
        ReplayLog:info("First rocket launched")
    end,
    afterReplay = function(self)
        if storage._REPLAY_SCRIPT_DATA["first-rocket"] ~= nil then
            ReplayLog:err("No rocket was launched in the replay!")
        end
    end
})

